/**
 ******************************************************************************
  * @file    user_diskio.c
  * @brief   This file includes a diskio driver skeleton to be completed by the user.
  ******************************************************************************
  *
  * COPYRIGHT(c) 2016 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* USER CODE BEGIN 0 */

/* Includes ------------------------------------------------------------------*/
#include <string.h>
#include "ff_gen_drv.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
extern SD_HandleTypeDef hsd;

#define uSdHandle hsd

#define BLOCK_SIZE                     512

#if defined(mSD_DETECT_Pin)
#define SD_DETECT()             HAL_GPIO_ReadPin (mSD_DETECT_GPIO_Port, mSD_DETECT_Pin)
#else
#define SD_DETECT()             GPIO_PIN_RESET
#endif
/* Private variables ---------------------------------------------------------*/
/* Disk status */
static volatile DSTATUS Stat = STA_NOINIT;

/* Private function prototypes -----------------------------------------------*/

DSTATUS USER_initialize (BYTE);
DSTATUS USER_status (BYTE);
DRESULT USER_read (BYTE, BYTE*, DWORD, UINT);
#if _USE_WRITE == 1
DRESULT USER_write (BYTE, const BYTE*, DWORD, UINT);  
#endif /* _USE_WRITE == 1 */
#if _USE_IOCTL == 1
DRESULT USER_ioctl (BYTE, BYTE, void*);  
#endif /* _USE_IOCTL == 1 */

Diskio_drvTypeDef  USER_Driver =
{
  USER_initialize,
  USER_status,
  USER_read, 
#if  _USE_WRITE
  USER_write,
#endif  /* _USE_WRITE == 1 */  
#if  _USE_IOCTL == 1
  USER_ioctl,
#endif /* _USE_IOCTL == 1 */
};

/* Private functions ---------------------------------------------------------*/

/**
* @brief  Initializes a Drive
* @param  pdrv: Physical drive number (0..)
* @retval DSTATUS: Operation status
*/
DSTATUS USER_initialize (
                         BYTE pdrv           /* Physical drive nmuber to identify the drive */
                           )
{
  Stat = STA_NOINIT;
  
  /* USER CODE HERE */
  if(SD_DETECT() == GPIO_PIN_RESET)/* If the SD card detected */
  {
    Stat &= ~STA_NOINIT;
  }

  return Stat;
}

/**
* @brief  Gets Disk Status 
* @param  pdrv: Physical drive number (0..)
* @retval DSTATUS: Operation status
*/
DSTATUS USER_status (
                     BYTE pdrv       /* Physical drive nmuber to identify the drive */
                       )
{
  Stat = STA_NOINIT;
  
  HAL_SD_TransferStateTypedef err;

  if(SD_DETECT() == GPIO_PIN_RESET)/* If the SD card detected */
  {  
    err = HAL_SD_GetStatus(&uSdHandle);
    
    if(err == SD_TRANSFER_OK)
    {
      Stat &= ~STA_NOINIT;
    }
  }
  
  return Stat;
}

/**
* @brief  Reads Sector(s) 
* @param  pdrv: Physical drive number (0..)
* @param  *buff: Data buffer to store read data
* @param  sector: Sector address (LBA)
* @param  count: Number of sectors to read (1..128)
* @retval DRESULT: Operation result
*/
DRESULT USER_read (
                   BYTE pdrv,      /* Physical drive nmuber to identify the drive */
                   BYTE *buff,     /* Data buffer to store read data */
                   DWORD sector,   /* Sector address in LBA */
                   UINT count      /* Number of sectors to read */
                     )
{
  /* USER CODE HERE */
  HAL_SD_ErrorTypedef err;
  
  err = HAL_SD_ReadBlocks(&uSdHandle, (uint32_t*)buff, (uint64_t) (sector * BLOCK_SIZE),  BLOCK_SIZE, count);
  
  if(err != SD_OK)
  {
    return RES_ERROR;
  }
  
  return RES_OK;
}

/**
* @brief  Writes Sector(s)  
* @param  pdrv: Physical drive number (0..)
* @param  *buff: Data to be written
* @param  sector: Sector address (LBA)
* @param  count: Number of sectors to write (1..128)
* @retval DRESULT: Operation result
*/
#if _USE_WRITE == 1
DRESULT USER_write (
                    BYTE pdrv,          /* Physical drive nmuber to identify the drive */
                    const BYTE *buff,   /* Data to be written */
                    DWORD sector,       /* Sector address in LBA */
                    UINT count          /* Number of sectors to write */
                      )
{ 
  /* USER CODE HERE */
  HAL_SD_ErrorTypedef err;
  
  err = HAL_SD_WriteBlocks(&uSdHandle, (uint32_t*)buff, (uint64_t)(sector * BLOCK_SIZE), BLOCK_SIZE, count);
  
  if(err != SD_OK)
  {
    return RES_ERROR;
  }
  
  return RES_OK;
}
#endif /* _USE_WRITE == 1 */

/**
* @brief  I/O control operation  
* @param  pdrv: Physical drive number (0..)
* @param  cmd: Control code
* @param  *buff: Buffer to send/receive control data
* @retval DRESULT: Operation result
*/
#if _USE_IOCTL == 1
DRESULT USER_ioctl (
                    BYTE pdrv,      /* Physical drive nmuber (0..) */
                    BYTE cmd,       /* Control code */
                    void *buff      /* Buffer to send/receive control data */
                      )
{
  DRESULT res = RES_ERROR;
  
  /* USER CODE HERE */
  HAL_SD_CardInfoTypedef CardInfo;
  
  if (Stat & STA_NOINIT) return RES_NOTRDY;
  
  switch (cmd)
  {
    /* Make sure that no pending write process */
  case CTRL_SYNC :
    res = RES_OK;
    break;
    
    /* Get number of sectors on the disk (DWORD) */
  case GET_SECTOR_COUNT :
    HAL_SD_Get_CardInfo(&uSdHandle, &CardInfo);
    *(DWORD*)buff = CardInfo.CardCapacity / BLOCK_SIZE;
    res = RES_OK;
    break;
    
    /* Get R/W sector size (WORD) */
  case GET_SECTOR_SIZE :
    *(WORD*)buff = BLOCK_SIZE;
    res = RES_OK;
    break;
    
    /* Get erase block size in unit of sector (DWORD) */
  case GET_BLOCK_SIZE :
    *(DWORD*)buff = BLOCK_SIZE;
    break;
    
  default:
    res = RES_PARERR;
  }
  
  return res;
}
#endif /* _USE_IOCTL == 1 */

/* USER CODE END 0 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
